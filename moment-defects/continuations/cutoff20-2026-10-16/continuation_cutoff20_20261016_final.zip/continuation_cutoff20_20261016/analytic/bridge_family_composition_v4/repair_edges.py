"""Explicit, whole-panel repaired-count edges; no numerical leaf oracle."""
from pathlib import Path
import sys
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2];A=HERE.parent;RETRIES=A/'actual_alpha8_v1'

def selection(core,graph,path,n,band):
 s=core.read(path);core.bind(graph,path)
 core.need(s['status']=='EXPLICIT_ACTUAL21_24_FULL_PANEL_ALPHA8_SELECTION_V2'and type(s['routes'])is list,'explicit reviewed-scope selection')
 chosen={};keys=set()
 for r in s['routes']:
  nn=r['n'];bb=r['band'];i=r['index'];core.need(type(nn)is int and nn in(21,22,23,24)and bb in('B0','BN')and type(i)is int and 0<i<99,'typed full retry scope');key=(nn,bb,i);core.need(key not in keys,'unique full retry scope');keys.add(key)
  S=RETRIES/f'n{nn}_{bb}_p{i}';core.need(r['scope']==str(S.relative_to(ROOT)),'literal actual retry scope path')
  review=(ROOT/r['source_review']).resolve();core.need(review.is_relative_to(ROOT),'workspace independent retry review')
  rv=core.closure(graph,review);freeze=S/'FROZEN.json';f=core.closure(graph,freeze)
  core.need(rv['status']=='PASS_INDEPENDENT_ACTUAL21_24_ALPHA8_FULL_PANEL_SOURCE_REVIEW','independent exact retry review')
  for p in(freeze,RETRIES/'run_action.py'):core.need(rv['files_sha256'].get(str(p.relative_to(ROOT)))==core.sha(p),'retry review binds exact scope/runtime')
  core.need(f['status']=='FROZEN_ACTUAL21_24_ALPHA8_FULL_PANEL_RETRY_V1'and f['n']==nn and type(f['n'])is int and f['band']==bb and f['index']==i and type(f['index'])is int and f['K']=='0'and f['root_count']==nn+1 and f['node_limit']==10000 and f['depth_limit']==128 and f['internal_seconds']==600 and f['external_seconds']==660,'same actual full-root retry')
  epoch=r['runtime_epoch'];core.need(epoch in('original_v1','extended_v2','acceptance_resume_v1'),'explicit supported runtime epoch');runtime=None
  if epoch=='original_v1':core.need('runtime_review'not in r,'old epoch has no new runtime edge')
  elif epoch=='extended_v2':
   E=A/'alpha8_runtime_v2';runtime_review=(ROOT/r['runtime_review']).resolve();core.need(runtime_review.is_relative_to(ROOT),'local runtime review')
   rr=core.closure(graph,runtime_review);rf=E/'FROZEN_RUNTIME.json';rfo=core.closure(graph,rf)
   core.need(rr['status']=='PASS_SAFE_EXTENDED_ALPHA8_COUNT_LAUNCHER_SOURCE_REVIEW'and rfo['status']=='FROZEN_DEADLINE_ONLY_ALPHA8_RUNTIME_WITH_EXPLICIT_PROVENANCE','reviewed explicit extended runtime')
   for p in(E/'run_action.py',rf,RETRIES/'run_action.py'):core.need(rr['files_sha256'].get(str(p.relative_to(ROOT)))==core.sha(p),'independent runtime review binds both launchers and epoch')
   core.need(rfo['original_launcher_sha256']==core.sha(RETRIES/'run_action.py'),'unchanged original proof launcher')
   runtime=dict(launcher=E/'run_action.py',review=runtime_review,freeze=rf)
  else:
   core.need((nn,bb,i)==(21,'BN',39),'only fixed interrupted-acceptance continuation')
   E=A/'acceptance_resume_v1';runtime_review=(ROOT/r['runtime_review']).resolve();core.need(runtime_review.is_relative_to(ROOT),'local continuation review')
   rr=core.closure(graph,runtime_review);rf=E/'FROZEN_RUNTIME.json';rfo=core.closure(graph,rf)
   core.need(rr['status']=='PASS_INDEPENDENT_ACTUAL21_BN39_FRESH_ACCEPTANCE_CONTINUATION_SOURCE_REVIEW'and rfo['status']=='FROZEN_ACTUAL21_BN39_ACCEPTANCE_CONTINUATION','reviewed fixed acceptance-only continuation')
   for p in(E/'run_action.py',rf,RETRIES/'run_action.py'):core.need(rr['files_sha256'].get(str(p.relative_to(ROOT)))==core.sha(p),'continuation review binds exact runtime and original source')
   C=S/'capsule';old_construct=C/'construct.execution.json';old_failed=C/'accept.execution.json';forest=C/'COUNT39_FOREST.json'
   core.need(rfo['original_launcher_sha256']==core.sha(RETRIES/'run_action.py')and rfo['original_capsule']==str(C.relative_to(ROOT))and rfo['original_scope_freeze_sha256']==core.sha(freeze)and rfo['original_construct_sha256']==core.sha(old_construct)and rfo['failed_original_acceptance_sha256']==core.sha(old_failed)and rfo['forest_sha256']==core.sha(forest)and rfo['construct_allowed']is False,'exact preserved original construction and interrupted replay')
   failed=core.read(old_failed);core.need(failed['status']=='INCOMPLETE_NATIVE_ACTION_PRESERVED'and failed['timed_out']is True and failed['interrupted']is False and failed['child_reaped']is True and type(failed['returncode'])is int and failed['returncode']!=0,'old deadline interruption is never promoted')
   runtime=dict(mode='acceptance_only',capture_dir=E,files=rfo['files_sha256'],launcher=E/'run_action.py',review=runtime_review,freeze=rf)
  if (nn,bb)==(n,band):chosen[i]=(S,freeze,f,review,runtime)
 return chosen

def inspect(core,graph,route,n,band,i,original,family,family_review,desc,geometry):
 S,freeze,f,review,runtime=route;C=S/'capsule';core.need(f['capsule']==str(C.relative_to(ROOT))and f['original_capsule']==str(original.relative_to(ROOT))and f['family']==str(family.relative_to(ROOT))and f['family_sha256']==core.sha(family)and f['family_review']==str(family_review.relative_to(ROOT))and f['family_review_sha256']==core.sha(family_review),'exact original acquired family and repaired namespace')
 core.need(f['contract_sha256']==core.sha(original/'contract.json')==core.sha(C/'contract.json')and core.sha(original/'SCALAR_DERIVATION.json')==core.sha(C/'SCALAR_DERIVATION.json')and core.sha(original/'count_protocol.py')==core.sha(C/'count_protocol.py')and core.sha(original/'KERNEL_COPY_MANIFEST.json')==core.sha(C/'KERNEL_COPY_MANIFEST.json'),'same full contract, scalar premises and fixed acceptor')
 old=core.read(original/'ROW_RESULT.json');core.need(f['prior_failure']==str((original/'ROW_RESULT.json').relative_to(ROOT))and f['prior_failure_sha256']==core.sha(original/'ROW_RESULT.json')and old['status']in('BOUNDED_ACTUAL_CONSTRUCTION_INCOMPLETE','INTERRUPTED_OR_FAILED_ACTUAL_CONSTRUCTION'),'preserved old incomplete never promoted')
 core.need(not(original/f'COUNT{i}_FOREST.json').exists()and not(original/f'COUNT{i}_ACCEPTED.json').exists(),'old incomplete namespace untouched')
 for action in('construct','accept'):
  active_runtime=runtime
  if runtime is not None and runtime.get('mode')=='acceptance_only'and action=='construct':active_runtime=None
  capture_dir=active_runtime['capture_dir']if active_runtime is not None and active_runtime.get('mode')=='acceptance_only'else C
  ep=capture_dir/(action+'.execution.json');pp=capture_dir/(action+'.process.json');e=core.read(ep);pr=core.read(pp)
  core.need(e['status']=='COMPLETED_NATIVE_ACTION'and type(e['returncode'])is int and e['returncode']==0 and e['timed_out']is False and e['interrupted']is False and e['child_reaped']is True and e['changed_inputs']==[],'complete fresh owned native action')
  core.need(e['n']==n and type(e['n'])is int and e['band']==band and e['index']==i and type(e['index'])is int and e['action']==action and e['capsule']==S.name,'literal actual capture')
  core.need(type(e['pid'])is int and e['pid']>0 and e['pgid']==e['pid']and type(e['pgid'])is int,'owned process group')
  suffix=['-B','-u',str(C/('construct_alpha4.py'if action=='construct'else'count_protocol.py'))]+([]if action=='construct'else['accept'])
  core.need(type(e['command'])is list and e['command'][1:]==suffix and e['cwd']==str(C),'unchanged actual native command')
  for k in('pid','pgid','command','cwd','action','capsule','n','band','index','started_utc'):core.need(core.same(e[k],pr[k]),'durable process linkage')
  core.need(pr['status']=='RUNNING_OWNED_CHILD'and pr['source_freeze_sha256']==core.sha(freeze)and pr['source_review_sha256']==core.sha(review)and e['process_record_sha256']==core.sha(pp),'reviewed exact launch provenance')
  runtime_keys=('runtime_review_sha256','runtime_freeze_sha256','launcher_sha256','launcher_path')
  if active_runtime is None:core.need(all(key not in e and key not in pr for key in runtime_keys),'original runtime record cannot silently carry extended provenance')
  else:
   expected_runtime=dict(runtime_review_sha256=core.sha(active_runtime['review']),runtime_freeze_sha256=core.sha(active_runtime['freeze']),launcher_sha256=core.sha(active_runtime['launcher']),launcher_path=str(active_runtime['launcher'].relative_to(ROOT)))
   for key,value in expected_runtime.items():core.need(core.same(e[key],value)and core.same(pr[key],value),'entire explicit extended runtime linkage')
  core.need(e['work_timeout_seconds']==660 and e['termination_grace_seconds']==5 and 0<e['effective_timeout_seconds']<=660,'bounded retained runtime')
  expected=dict(active_runtime['files']if active_runtime is not None and active_runtime.get('mode')=='acceptance_only'else f['files_sha256']);expected[str(freeze.relative_to(ROOT))]=core.sha(freeze);expected[str(review.relative_to(ROOT))]=core.sha(review)
  if active_runtime is not None:
   for key in('launcher','review','freeze'):
    p=active_runtime[key];expected[str(p.relative_to(ROOT))]=core.sha(p)
  if action=='accept':expected[str((C/f'COUNT{i}_FOREST.json').relative_to(ROOT))]=core.sha(C/f'COUNT{i}_FOREST.json')
  core.need(core.same(e['inputs_sha256'],expected),'entire exact runtime input map')
  for key,z in expected.items():core.bind(graph,ROOT/key,z)
  for name in('stdout','stderr'):core.bind(graph,capture_dir/(action+'.'+name+'.txt'),e[name+'_sha256'])
  core.need(not(capture_dir/(action+'.stderr.txt')).read_bytes(),'successful empty native stderr');out=C/('CONSTRUCTION_RUN.json'if action=='construct'else f'COUNT{i}_ACCEPTED.json');native=core.read(out)
  core.need(core.same(native,core.read(capture_dir/(action+'.stdout.txt'))),'whole native captured JSON')
  required=[C/f'COUNT{i}_FOREST.json',C/'CONSTRUCTION_RUN.json']+([C/f'COUNT{i}_ACCEPTED.json']if action=='accept'else[])
  core.need(e['outputs_sha256']=={str(p.relative_to(ROOT)):core.sha(p)for p in required},'complete actual output inventory')
  if action=='construct':core.need(native['status']=='STORED_CONDITIONAL_FOREST_CONSTRUCTED_NOT_ACCEPTED'and native['forest_sha256']==core.sha(C/f'COUNT{i}_FOREST.json')and native['constructor_sha256']==core.sha(C/'construct_alpha4.py')and native['fixed_acceptor_sha256']==core.sha(C/'count_protocol.py')and native['contract_sha256']==core.sha(C/'contract.json'),'fresh whole native candidate')
  else:core.need(native['status']==desc['status']==f['native_acceptance_status'],'exact native fresh acceptance')
  for p in(ep,pp,out):core.bind(graph,p)
 receipt=C/f'COUNT{i}_ACCEPTED.json';inspection=geometry.inspect_capsule(receipt)
 core.need(inspection['n']==n and inspection['index']==i and inspection['subpanel']is None,'same complete actual full panel')
 for p in(C/f'COUNT{i}_FOREST.json',receipt):core.bind(graph,p)
 return C,receipt,inspection
