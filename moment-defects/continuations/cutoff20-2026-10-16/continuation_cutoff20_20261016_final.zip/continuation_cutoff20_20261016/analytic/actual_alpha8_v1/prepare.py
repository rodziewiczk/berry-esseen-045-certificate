"""Source-only exact full-panel retry; never evaluates a count cell."""
from pathlib import Path
from hashlib import sha256
import json,sys
H=Path(__file__).resolve().parent;ROOT=H.parents[2];A=H.parent;P=ROOT/'continuation_cutoff20_20261016/b0/bridge_counts_v3'
def need(x,m):
 if not x:raise ValueError(m)
def sha(p):return sha256(p.read_bytes()).hexdigest()
def unique(pairs):
 d={}
 for k,v in pairs:need(k not in d,'duplicate JSON key');d[k]=v
 return d
def read(p):return json.loads(p.read_text(),object_pairs_hook=unique)
def write(p,v):
 with p.open('x')as f:json.dump(v,f,indent=2);f.write('\n')
def bind(g,p,h=None):
 p=p.resolve();need(p.is_relative_to(ROOT)and p.is_file(),'workspace file');z=sha(p);need(h is None or h==z,'exact dependency');k=str(p.relative_to(ROOT));need(k not in g or g[k]==z,'consistent dependency');g[k]=z

def prepare(n,band,i):
 need(type(n)is int and n in(21,22,23,24)and band in('B0','BN')and type(i)is int and 0<i<99,'literal actual full panel')
 family=P/f'n{n}_{band}'/'FROZEN.json';f=read(family);review=A/f'ACTUAL{n}_{band}_COUNT_FAMILY_SOURCE_REVIEW.json';r=read(review);old=family.parent/f'capsule{i}';failure=old/'ROW_RESULT.json';bad=read(failure)
 need(f['n']==n and type(f['n'])is int and f['band']==band and f['K']=='0','actual family')
 need(r['status']=='PASS_INDEPENDENT_ACTUAL21_24_COUNT_FAMILY_SOURCE_REVIEW'and r['family_sha256']==sha(family),'independent acquired family review')
 need(bad['status']in('BOUNDED_ACTUAL_CONSTRUCTION_INCOMPLETE','INTERRUPTED_OR_FAILED_ACTUAL_CONSTRUCTION')and bad['n']==n and type(bad['n'])is int and bad['band']==band and bad['index']==i and type(bad['index'])is int,'preserved genuine prior incomplete')
 need(bad['source_freeze_sha256']==sha(family)and bad['source_review_sha256']==sha(review)and bad['contract_sha256']==sha(old/'contract.json'),'same original acquired conditional contract')
 need(not(old/f'COUNT{i}_FOREST.json').exists()and not(old/f'COUNT{i}_ACCEPTED.json').exists(),'no accepted old proof replaced')
 desc=[x for x in f['rows']if x['index']==i];need(len(desc)==1 and desc[0]['directory']==str(old.relative_to(ROOT)),'original whole-panel descriptor')
 g={};bind(g,family);bind(g,review);bind(g,failure)
 for src in(f,r):
  for k,z in src['files_sha256'].items():bind(g,ROOT/k,z)
 cap=ROOT/bad['runs']['construct']['path'];bind(g,cap/'EXECUTION.json',bad['runs']['construct']['execution_sha256'])
 for name in('STARTED.json','stdout.txt','stderr.txt'):bind(g,cap/name)
 for name in('CONSTRUCTION_RUN.json',):
  if(old/name).exists():bind(g,old/name)
 for name in('prepare.py','run_action.py','PROOF.txt'):bind(g,H/name)
 dest=H/f'n{n}_{band}_p{i}';dest.mkdir(exist_ok=False);C=dest/'capsule';C.mkdir();copies={};prefix=str(old.relative_to(ROOT))+'/'
 for k,z in f['files_sha256'].items():
  if not k.startswith(prefix):continue
  p=ROOT/k;q=C/p.name;need(q.name==k[len(prefix):],'flat capsule source')
  if p.name=='construct_alpha4.py':continue
  q.write_bytes(p.read_bytes());bind(g,q,z);copies[p.name]=dict(source=k,sha256=z)
 source=old/'construct_alpha4.py';text=source.read_text();transforms=[['widths[2]*=4*','widths[2]*=8*'],['time.time()-started<=270','time.time()-started<=600']]
 for a,b in transforms:need(text.count(a)==1,'unique constructor-only literal');text=text.replace(a,b)
 (C/'construct_alpha4.py').write_text(text);bind(g,C/'construct_alpha4.py')
 port=dict(source=str(source.relative_to(ROOT)),source_sha256=sha(source),transforms=transforms,whole_output_sha256=sha(C/'construct_alpha4.py'),copies=copies)
 write(dest/'SOURCE_PORT.json',port);bind(g,dest/'SOURCE_PORT.json')
 freeze=dict(status='FROZEN_ACTUAL21_24_ALPHA8_FULL_PANEL_RETRY_V1',n=n,K='0',band=band,index=i,capsule=str(C.relative_to(ROOT)),family=str(family.relative_to(ROOT)),family_sha256=sha(family),family_review=str(review.relative_to(ROOT)),family_review_sha256=sha(review),original_capsule=str(old.relative_to(ROOT)),prior_failure=str(failure.relative_to(ROOT)),prior_failure_sha256=sha(failure),native_acceptance_status=desc[0]['status'],contract_sha256=sha(C/'contract.json'),internal_seconds=600,external_seconds=660,node_limit=10000,depth_limit=128,root_count=n+1,files_sha256=g,predecessor_verified=False,global_bound_proved=False,cutoff20_proved=False,numerical_oracle_calls=0)
 write(dest/'FROZEN.json',freeze);print(str(dest.relative_to(ROOT)),sha(dest/'FROZEN.json'))
if __name__=='__main__':
 need(__debug__ and sys.flags.dont_write_bytecode and len(sys.argv)==4,'-B actualn band index');n=int(sys.argv[1]);i=int(sys.argv[3]);need(str(n)==sys.argv[1]and str(i)==sys.argv[3],'literal integers');prepare(n,sys.argv[2],i)
