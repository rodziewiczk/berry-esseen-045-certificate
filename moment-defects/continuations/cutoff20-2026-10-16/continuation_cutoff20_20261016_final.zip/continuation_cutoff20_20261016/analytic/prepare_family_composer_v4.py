"""Source-only acceptance-continuation edge; unchanged mathematical composition."""
from pathlib import Path
from hashlib import sha256
import json,difflib,ast
A=Path(__file__).resolve().parent;ROOT=A.parents[1];OLD=A/'bridge_family_composition_v3';H=A/'bridge_family_composition_v4';H.mkdir(exist_ok=False);ports={}
h=lambda p:sha256(p.read_bytes()).hexdigest()
def transform(name,replacements):
 s=(OLD/name).read_text();items=[]
 for a,b in replacements:
  assert s.count(a)==1,(name,a,s.count(a));s=s.replace(a,b);items.append([a,b])
 ast.parse(s);(H/name).write_text(s);(H/(name+'.diff')).write_text(''.join(difflib.unified_diff((OLD/name).read_text().splitlines(True),s.splitlines(True),fromfile=str(OLD/name),tofile=str(H/name))))
 ports[name]=dict(source=str((OLD/name).relative_to(ROOT)),source_sha256=h(OLD/name),transforms=items,new_sha256=h(H/name))
transform('compose.py',[
 ('PASS_INDEPENDENT_ACTUAL21_24_MIXED_RUNTIME_FAMILY_COMPOSITION_SOURCE_REVIEW','PASS_INDEPENDENT_ACTUAL21_24_ACCEPTANCE_CONTINUATION_FAMILY_COMPOSITION_SOURCE_REVIEW'),
 ('FROZEN_ACTUAL21_24_CONDITIONAL_FAMILY_COMPOSITOR_V3','FROZEN_ACTUAL21_24_CONDITIONAL_FAMILY_COMPOSITOR_V4')])
transform('repair_edges.py',[
 ("epoch in('original_v1','extended_v2')","epoch in('original_v1','extended_v2','acceptance_resume_v1')"),
 ("  else:\n   E=A/'alpha8_runtime_v2';", "  elif epoch=='extended_v2':\n   E=A/'alpha8_runtime_v2';"),
 ("  if (nn,bb)==(n,band):chosen[i]=(S,freeze,f,review,runtime)","""  else:
   core.need((nn,bb,i)==(21,'BN',39),'only fixed interrupted-acceptance continuation')
   E=A/'acceptance_resume_v1';runtime_review=(ROOT/r['runtime_review']).resolve();core.need(runtime_review.is_relative_to(ROOT),'local continuation review')
   rr=core.closure(graph,runtime_review);rf=E/'FROZEN_RUNTIME.json';rfo=core.closure(graph,rf)
   core.need(rr['status']=='PASS_INDEPENDENT_ACTUAL21_BN39_FRESH_ACCEPTANCE_CONTINUATION_SOURCE_REVIEW'and rfo['status']=='FROZEN_ACTUAL21_BN39_ACCEPTANCE_CONTINUATION','reviewed fixed acceptance-only continuation')
   for p in(E/'run_action.py',rf,RETRIES/'run_action.py'):core.need(rr['files_sha256'].get(str(p.relative_to(ROOT)))==core.sha(p),'continuation review binds exact runtime and original source')
   C=S/'capsule';old_construct=C/'construct.execution.json';old_failed=C/'accept.execution.json';forest=C/'COUNT39_FOREST.json'
   core.need(rfo['original_launcher_sha256']==core.sha(RETRIES/'run_action.py')and rfo['original_capsule']==str(C.relative_to(ROOT))and rfo['original_scope_freeze_sha256']==core.sha(freeze)and rfo['original_construct_sha256']==core.sha(old_construct)and rfo['failed_original_acceptance_sha256']==core.sha(old_failed)and rfo['forest_sha256']==core.sha(forest)and rfo['construct_allowed']is False,'exact preserved original construction and interrupted replay')
   failed=core.read(old_failed);core.need(failed['status']=='INCOMPLETE_NATIVE_ACTION_PRESERVED'and failed['timed_out']is True and failed['interrupted']is False and failed['child_reaped']is True and type(failed['returncode'])is int and failed['returncode']!=0,'old deadline interruption is never promoted')
   runtime=dict(mode='acceptance_only',capture_dir=E,files=rfo['files_sha256'],launcher=E/'run_action.py',review=runtime_review,freeze=rf)
  if (nn,bb)==(n,band):chosen[i]=(S,freeze,f,review,runtime)"""),
 ("  ep=C/(action+'.execution.json');pp=C/(action+'.process.json');e=core.read(ep);pr=core.read(pp)","""  active_runtime=runtime
  if runtime is not None and runtime.get('mode')=='acceptance_only'and action=='construct':active_runtime=None
  capture_dir=active_runtime['capture_dir']if active_runtime is not None and active_runtime.get('mode')=='acceptance_only'else C
  ep=capture_dir/(action+'.execution.json');pp=capture_dir/(action+'.process.json');e=core.read(ep);pr=core.read(pp)"""),
 ("  if runtime is None:core.need", "  if active_runtime is None:core.need"),
 ("expected_runtime=dict(runtime_review_sha256=core.sha(runtime['review']),runtime_freeze_sha256=core.sha(runtime['freeze']),launcher_sha256=core.sha(runtime['launcher']),launcher_path=str(runtime['launcher'].relative_to(ROOT)))", "expected_runtime=dict(runtime_review_sha256=core.sha(active_runtime['review']),runtime_freeze_sha256=core.sha(active_runtime['freeze']),launcher_sha256=core.sha(active_runtime['launcher']),launcher_path=str(active_runtime['launcher'].relative_to(ROOT)))"),
 ("  expected=dict(f['files_sha256']);expected[str(freeze.relative_to(ROOT))]=core.sha(freeze);expected[str(review.relative_to(ROOT))]=core.sha(review)\n  if runtime is not None:\n   for p in runtime.values():expected[str(p.relative_to(ROOT))]=core.sha(p)","""  expected=dict(active_runtime['files']if active_runtime is not None and active_runtime.get('mode')=='acceptance_only'else f['files_sha256']);expected[str(freeze.relative_to(ROOT))]=core.sha(freeze);expected[str(review.relative_to(ROOT))]=core.sha(review)
  if active_runtime is not None:
   for key in('launcher','review','freeze'):
    p=active_runtime[key];expected[str(p.relative_to(ROOT))]=core.sha(p)"""),
 ("core.bind(graph,C/(action+'.'+name+'.txt'),e[name+'_sha256'])", "core.bind(graph,capture_dir/(action+'.'+name+'.txt'),e[name+'_sha256'])"),
 ("not(C/(action+'.stderr.txt')).read_bytes()", "not(capture_dir/(action+'.stderr.txt')).read_bytes()"),
 ("core.same(native,core.read(C/(action+'.stdout.txt')))", "core.same(native,core.read(capture_dir/(action+'.stdout.txt')))")])
(H/'SOURCE_PORTS.json').write_text(json.dumps(ports,indent=2)+'\n')
(H/'PROOF.txt').write_text('The mathematical and all100 closed probability-panel composition body is byte-identical to v3 apart from its independent-source-review and freeze status labels. Every resource, scalar, whole signed-quadratic, physical mean/beta, exact native target and original-root geometry check remains unchanged.\n\nThe sole additional runtime route is literal actual21/BN/p39. It uses the original successfully captured construction and its complete unchanged forest, then a separately reviewed fresh native acceptance in a new capture namespace. The original timed-out and reaped acceptance is pinned as preserved failure, never promoted. The new native acceptance still invokes the identical original fixed count_protocol.py on the identical complete forest, writes the previously absent native acceptance receipt, and binds its entire original plus continuation source/input map. Its durable process, command, cwd, bounded cleanup, complete native stdout/output inventory and exact runtime review/epoch are all checked. Original construction must use old provenance; only acceptance may use the new namespace. No other panel may use this route.\n\nOther original/extended runtime routes are unchanged. The old failed captures remain immutable. New acceptance metadata alone does not imply success: absent, partial, timed-out, changed-input, wrong-source or wrong-scope records reject. The conclusion remains an actual-n complete band implication conditional on globally sharp(n-1) within the retained unrestricted-witness framework, not a global theorem or cutoff claim. Composition invokes no numerical leaf or resource oracle.\n')
d=json.loads((OLD/'SELECTED_FOURTEEN_MIXED_V1.json').read_text())
for r in d['routes']:
 if(r['n'],r['band'],r['index'])==(21,'BN',39):
  r['runtime_epoch']='acceptance_resume_v1';r['runtime_review']='continuation_cutoff20_20261016/root/ACTUAL21_BN39_ACCEPTANCE_CONTINUATION_SOURCE_REVIEW.json'
d['routes'].append(dict(n=23,band='BN',index=40,scope='continuation_cutoff20_20261016/analytic/actual_alpha8_v1/n23_BN_p40',source_review='continuation_cutoff20_20261016/root/ACTUAL_ALPHA8_FULL_PANEL_SOURCE_REVIEW_V6.json',runtime_epoch='extended_v2',runtime_review='continuation_cutoff20_20261016/root/ALPHA8_EXTENDED_RUNTIME_V2_SOURCE_REVIEW.json'))
(H/'SELECTED_FIFTEEN_CONTINUATION_V1.json').write_text(json.dumps(d,indent=2)+'\n')
g={}
for p in(OLD/'FROZEN_SOURCES.json',ROOT/'continuation_cutoff20_20261016/root/ACTUAL_MIXED_RUNTIME_COMPOSITOR_V3_SOURCE_REVIEW.json',ROOT/'continuation_cutoff20_20261016/root/ACTUAL21_BN39_ACCEPTANCE_CONTINUATION_SOURCE_REVIEW.json',ROOT/'continuation_cutoff20_20261016/root/ACTUAL_ALPHA8_FULL_PANEL_SOURCE_REVIEW_V6.json'):
 o=json.loads(p.read_text());g[str(p.relative_to(ROOT))]=h(p)
 for k,z in o.get('files_sha256',{}).items():assert h(ROOT/k)==z;assert k not in g or g[k]==z;g[k]=z
for p in list(H.iterdir())+[Path(__file__)]:g[str(p.relative_to(ROOT))]=h(p)
f=dict(status='FROZEN_ACTUAL21_24_CONDITIONAL_FAMILY_COMPOSITOR_V4',files_sha256=g,source_only=True,numerical_oracle_calls=0,mathematical_bounds_changed=False,complete_band_or_global_conclusion_asserted=False)
(H/'FROZEN_SOURCES.json').write_text(json.dumps(f,indent=2)+'\n');print(h(H/'FROZEN_SOURCES.json'),len(g))
