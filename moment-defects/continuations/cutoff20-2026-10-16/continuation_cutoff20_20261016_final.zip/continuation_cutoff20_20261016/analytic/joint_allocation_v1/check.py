"""Exact actual-law and closed-boundary fixtures, not a count proof."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json,sys
import allocation as a
import joint_v3 as old
H=Path(__file__).resolve().parent;R=H.parents[2]
def sha(p):return sha256(p.read_bytes()).hexdigest()
def need(x,m):
    if not x:raise ValueError(m)
def main():
    need(__debug__ and sys.flags.dont_write_bytecode,'ordinary no-bytecode runtime')
    need(sha(H/'joint_v3.py')=='b8f940134ab54312bf2651c45f2ec94588ba42cd11694077828d910ad815f463','immutable prior V3')
    laws=boxes=linear=quadratic=0
    for p in map(F,['1/100','3/20','37/100','1/2','3/5','43/50','99/100']):
        q=1-p;v=p*q
        for x,y in [(F(0),F(0)),(p/10,F(0)),(F(0),q/10),(p/2,q/2),(p,q/10),(p/10,q),(p/10**9,q/10**9)]:
            for t0,t1 in [(F(1,10),F(1,9)),(F(1,10000),F(1,100000)),(F(10**6),F(1,3))]:
                def noise(cap,tail):return [(F(1),F(0))] if cap==0 else [(tail/(cap+tail),cap),(cap/(cap+tail),-tail)]
                left=[(q*w,-p+u) for w,u in noise(x,t0)]
                right=[(p*w,q-u) for w,u in noise(y,t1)]
                atoms=left+right
                need(sum(w for w,u in atoms)==1 and sum(w*u for w,u in atoms)==0,'centered law')
                m2=sum(w*u*u for w,u in atoms);m3=sum(w*abs(u)**3 for w,u in atoms)
                s=m2-v;c=sum(w*(u-q)**2 for w,u in right);alpha=c/s if s else F(1,2)
                rho=old.roots(m3*m3/m2**3)[1];d=max(x+y,F(1,100))
                for width in (F(0),min(F(1,100),p/2,q/2)):
                    args=(p-width,p+width,max(F(0),alpha-width),min(F(1),alpha+width),max(F(0),s-width),s+width,d,rho)
                    for L,U in [(x,x),(max(F(0),x-d/10),min(d,x+d/10)),(F(0),d)]:
                        z=a.test(*args,L,U);o=old.test(*args)
                        coeff=z['coefficients'];need(coeff[0]+coeff[1]*s+coeff[2]*s*s<=0 and not z['empty'],'actual law retained')
                        need(coeff[0]==o['coefficients'][0] and coeff[1]>=o['coefficients'][1] and coeff[2]>=o['coefficients'][2],'coefficient domination')
                        linear+=int(z['allocation_linear_gain']>0);quadratic+=int(z['allocation_quadratic_gain']>0);boxes+=1
                laws+=1
    args=(F(1,2),F(1,2),F(0),F(1),F(0),F(0),F(1,10),F(1))
    for L,U in [(F(0),F(0)),(F(1,10),F(1,10)),(F(0),F(1,10))]:
        z=a.test(*args,L,U);need(z['minimum']==0 and not z['empty'],'Bernoulli equality')
    bad=0
    for L,U in [(0,F(1,10)),(F(-1),F(0)),(F(1,10),F(0)),(F(0),F(1,5))]:
        try:a.test(*args,L,U)
        except ValueError:bad+=1
        else:raise ValueError('malformed inward interval accepted')
    # Deliberately compare an actual failed frontier, without treating it as a law.
    olddir=R/'cutoff20_20261016/fourier/feedback_bn_remaining_v1/capsule39'
    cfg=json.loads((olddir/'contract.json').read_text())['rows'][0]
    b=[[F(x) for x in y] for y in json.loads((olddir/'CONSTRUCTION_RUN.json').read_text())['last_open']['box']]
    pl,pu=b[0];lo,hi=b[1];al,ah=b[2];L,U=b[4];n=cfg['n'];original_lambda=F(cfg['Lambda'])
    d=min(F(cfg['d0'])*(1-lo/original_lambda),(F(cfg['D'])-F(cfg['binary_charge'])-F(cfg['noise_charge'])*lo)/F(cfg['gap_charge']))
    U=min(U,d);need(0<=L<=U,'frontier inward interval')
    z=a.test(pl,pu,al,ah,lo/n,hi/n,d,F(cfg['rho_upper']),L,U)
    bound={str(p.relative_to(R)):sha(p) for p in [Path(__file__),H/'PROOF.txt',H/'allocation.py',H/'joint_v3.py',olddir/'contract.json',olddir/'CONSTRUCTION_RUN.json',R/'cutoff20_20261016/root/joint_endpoint_v3/PROOF.txt']}
    out=dict(status='PASS_EXACT_ACTUAL_LAW_ALLOCATION_FIXTURES_NOT_COUNT_PROOF',actual_laws=laws,boxes=boxes,strict_linear_gain_boxes=linear,strict_quadratic_gain_boxes=quadratic,closed_zero_noise_controls=3,malformed_controls=bad,bn39_failed_frontier=dict(minimum=str(z['minimum']),linear_gain=str(z['allocation_linear_gain']),quadratic_gain=str(z['allocation_quadratic_gain']),empty=z['empty']),files_sha256=bound)
    with(H/'CHECKED.json').open('x')as f:json.dump(out,f,indent=2);f.write('\n')
    print(json.dumps({k:v for k,v in out.items() if k!='files_sha256'}))
if __name__=='__main__':main()
