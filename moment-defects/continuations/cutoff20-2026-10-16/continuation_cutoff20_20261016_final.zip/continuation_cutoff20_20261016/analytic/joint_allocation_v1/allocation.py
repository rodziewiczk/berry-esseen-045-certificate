"""Necessary allocation-aware marginal moment quadratic; no count wrapper."""
from fractions import Fraction as F
import joint_v3 as prior

def test(pl,pu,al,ah,sl,sh,d,R,a0l,a0h):
    z=prior.test(pl,pu,al,ah,sl,sh,d,R)
    prior.need(type(a0l)is F and type(a0h)is F,'exact inward interval')
    prior.need(0<=a0l<=a0h<=d,'intersected same-law inward interval')
    ps=(z['probability_endpoint'],) if z['probability_endpoint'] is not None else (pl,pu)
    def linear(p,a,x):
        return 3*p*(1-a)+3*(1-p)*a-x*(1-a)-(d-x)*a
    B=min(linear(p,a,x) for p in ps for a in (al,ah) for x in (a0l,a0h))
    Q=(1-pl)*a0h; P=pu*(d-a0l)
    K=z['H_lower']/d; Ka=None; a=None
    if Q>0 and P>0:
        a=max(al,min(ah,P/(P+Q)))
        Ka=(1-a)**2/Q+a*a/P
        K=max(K,Ka)
    old=z['coefficients'];c0=old[0]
    c1=old[1]+B-z['B_lower']
    c2=old[2]+K-z['H_lower']/d
    prior.need(c1>=old[1] and c2>=old[2],'proved coefficient improvements')
    m=prior.minimum(c0,c1,c2,sl,sh)
    return dict(empty=m>0,minimum=m,coefficients=[c0,c1,c2],
                prior_coefficients=old,probability_endpoint=z['probability_endpoint'],
                allocation_linear_gain=c1-old[1],allocation_quadratic_gain=c2-old[2],
                allocation_alpha_minimizer=a,allocation_quadratic_lower=Ka,
                inward_lower=a0l,inward_upper=a0h,common_inward_upper=d,
                status='NECESSARY_MARGINAL_QUADRATIC_NOT_COUNT_PROOF')
