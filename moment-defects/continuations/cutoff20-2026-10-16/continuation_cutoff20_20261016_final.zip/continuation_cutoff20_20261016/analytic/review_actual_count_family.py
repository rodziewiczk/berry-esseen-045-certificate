"""Independent actual-family resource/scalar/source audit, without score calls."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
from copy import deepcopy
import json,sys,subprocess,inspect
import review_scalar_moments as m
import review_bn_interfaces as bi
H=Path(__file__).resolve().parent;ROOT=H.parents[1];P=ROOT/'continuation_cutoff20_20261016/b0/bridge_counts_v3'
need=m.need;enc=m.enc;up=bi.up;down=bi.down;minimum=bi.minimum

def sha(p):return sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
# Independent standard-library trace functions, with only literal actual-n scale.
ns=dict(m.__dict__)
for fn in (m.coupled_check,m.monotone_check):
 s=inspect.getsource(fn);name=fn.__name__
 s=s.replace('stored):','stored,n):')if name=='coupled_check'else s.replace('raw,m):','raw,m,n):')
 s=s.replace('/20','/n').replace('20*S','n*S')
 exec(compile(s,str(Path(__file__))+':actual_'+name,'exec'),ns)

def base(row,n,band,i):
 r=row['result']['result'];raw=row['result']['raw_row'];s=row['source'];lo,hi={'B0':('1','11/10'),'BN':('11/10','9/8')}[band]
 need(type(row['n'])is int and row['n']==n and row['index']==i and type(row['index'])is int and row['band']==band and row['status']=='RESOURCE_ROW_ACQUIRED_FOR_COUNT' and row['result']['excluded']is False,'actual row')
 p=[str(F(i,100)),str(F(i+1,100))];need(type(r['N'])is int and r['N']==n and r['K']=='0'and r['index']==i and type(r['index'])is int,'actual native n')
 need([r['pl'],r['pu']]==[raw['pl'],raw['pu']]==[s['pl'],s['pu']]==p and s['rho_lo']==r['rho_lo']==lo and F(lo)<=F(r['rho_hi'])<=F(hi),'whole closed physical scope')
 z=dict(n=n,K='0',index=i,p=p,rho_lower=lo,rho_upper=str(up(r['rho_hi'])))
 for a,b in [('D','D'),('d0','d0'),('lambda_max','Lambda'),('H_minus','Hminus'),('H_plus','Hplus'),('radius_minus','radius_minus'),('radius_plus','radius_plus'),('outer0','outer0'),('outer1','outer1')]:z[b]=str(up(r[a]))
 for a,b in [('charge_b','binary_charge'),('charge_g','gap_charge'),('charge_h','noise_charge')]:z[b]=str(down(r[a]))
 need(F(r['D'])-F(r['charge_b'])==F(r['charge_g'])*F(r['d0'])==F(r['charge_h'])*F(r['lambda_max'])>0,'shared original budget')
 z['quadratics']=[{k:str(down(q[k])if k=='Qbudget'else up(q[k]))for k in ('A','Fplus','Fminus','Qbudget')}for q in r['quadratics']]
 z['sign_premise']=dict(schema='ACTUAL_SIGN_CONDITIONED_MARGINAL_V1',resource_status='ASSUMED_ACQUIRED_FOR_CONDITIONAL_TEST',conditional_means_zero=True,negative_endpoint_lower=str(down(raw['A'])),positive_endpoint_lower=str(down(raw['B'])))
 z['acquired_beta']=[str(down(max(F(s['beta_lo']),F(raw['beta_lo'])))),str(min(F(1),up(min(F(s['beta']),F(raw['beta_hi_signed'])))))]
 z['acquired_mean']=[str(max(F(0),down(s['mean_lo']))),str(min(F(1,2),up(min(F(s['mean_hi']),F(raw['mean_hi'])))))]
 margins=[minimum(F(t['A'])-F(q['A']),F(t['F'+sgn])-F(q['F'+sgn]),F(q['Qbudget'])-F(t['Qbudget']),F(z['H'+sgn]))for sgn in ('plus','minus')for q,t in zip(r['quadratics'],z['quadratics'])]
 need(all(x>=0 for x in margins),'full signed quadratic enclosures')
 need(0<F(z['sign_premise']['negative_endpoint_lower'])<=F(raw['A'])and 0<F(z['sign_premise']['positive_endpoint_lower'])<=F(raw['B']),'physical endpoints')
 need(-1<=F(z['acquired_beta'][0])<=max(F(s['beta_lo']),F(raw['beta_lo']))<=min(F(s['beta']),F(raw['beta_hi_signed']))<=F(z['acquired_beta'][1])<=1,'signed beta')
 need(0<=F(z['acquired_mean'][0])<=F(s['mean_lo'])<=min(F(s['mean_hi']),F(raw['mean_hi']))<=F(z['acquired_mean'][1])<=F(1,2),'physical mean')
 need(F(1,4)+F(z['Lambda'])/n<1 and n*F(p[0])>F(z['Hminus'])and n*F(p[1])+F(z['Hplus'])<n,'all actual nearest roots')
 return z,list(map(str,margins))

def scalar(raw,stored,n,band,i):
 need(stored['source_cfg']==raw and stored['index']==i and stored['original_count_p']==[raw['pl'],raw['pu']],'same scalar source')
 l,u=m.folded(stored['original_count_p']);need(stored['scalar_p']==[str(l),str(u)]and stored['reflected_for_scalar_only']==(F(raw['pl'])>=F(1,2))and stored['count_orientation_unchanged']is True,'scalar-only reflection')
 mono=stored['monotone_map'];ns['monotone_check'](raw,mono,n)
 d=min(F(raw['d0']),(F(raw['D'])-F(raw['charge_b']))/F(raw['charge_g']));lo=F(raw['rho_lo']);cap=F(raw['lambda_max'])
 if mono['status']in ('PASS_NECESSARY_SCALAR_CONTRACTION','INWARD_MOMENT_CONTRADICTION'):lo=max(lo,F(mono['rho_floor']))
 if mono['status']=='PASS_NECESSARY_SCALAR_CONTRACTION':cap=min(cap,F(mono['lambda_upper']))
 if d<=l:
  vl=l*(1-l);vh=u*(1-u);rb=m.root((1-2*vh)**2/vh)
  if d==0:loss=F(0);cap=F(0);detail=dict(kind='zero_noise',bernoulli_floor=str(rb),loss_upper='0')
  else:
   a=max(F(0),F(3,2)-6*l+3*l*l+d);B=2*l/d-F(3,2)*u;need(B>=F(5,4),'positive scalar loss denominator');loss=a*a/(2*B*m.root(vl));detail=enc(dict(kind='quadratic_deficit',a=a,b=B,sqrt_v_lower=m.root(vl),bernoulli_floor=rb,loss_upper=loss))
  lo=max(lo,rb-loss)
 else:detail=dict(kind='gate_not_established')
 need(stored['deficit_map']==detail and stored['overlay']==dict(rho_lo=str(lo),lambda_max=str(cap))and F(stored['rho_floor'])==lo and F(stored['lambda_upper'])==cap and F(stored['inward_upper'])==d,'all independent scalar maps')
 need(stored['status']==('EXCLUDED_BY_NEW_INWARD_MOMENT'if lo>F(raw['rho_hi'])else'SCALAR_OVERLAY_READY_FOR_NEW_COUNT_EPOCH'),'strict scalar status');return lo,cap

def main():
 need(__debug__ and sys.flags.dont_write_bytecode and len(sys.argv)==3,'ordinary-B actualn band');n=int(sys.argv[1]);band=sys.argv[2];need(n in(21,22,23,24)and band in('B0','BN'),'declared actual family')
 sys.path.insert(0,str(P));import prepare_family as pf
 d=P/f'n{n}_{band}';freeze=d/'FROZEN.json';f=read(freeze);graph=dict(f['files_sha256'])
 for p,h in graph.items():need(sha(ROOT/p)==h,'whole frozen family')
 source_review=H/'BRIDGE_COUNT_FRAMEWORK_SOURCE_REVIEW.json';sr=read(source_review);need(sr['status']=='PASS_INDEPENDENT_ACTUAL21_24_COUNT_FRAMEWORK_SOURCE_REVIEW'and sr['files_sha256'][str((P/'FROZEN_FRAMEWORK.json').relative_to(ROOT))]==sha(P/'FROZEN_FRAMEWORK.json'),'approved complete framework')
 for p,h in sr['files_sha256'].items():need(sha(ROOT/p)==h,'reviewed framework bytes')
 parentgraph={};pc,pa,rows=pf.parent(n,band,parentgraph)
 need(f['n']==n and type(f['n'])is int and f['band']==band and f['K']=='0'and len(f['dispositions'])==100,'whole actual family scope')
 need(f['parent_candidate_sha256']==sha(pf.PARENT/f'n{n}_{band}/CANDIDATE.json')and f['parent_acceptance_sha256']==sha(pf.PARENT/f'n{n}_{band}/ACCEPTED.json')and all(f[k]is False for k in('predecessor_verified','global_bound_proved','cutoff20_proved')),'literal conditional parent')
 descs={x['index']:x for x in f['rows']};need(len(descs)==len(f['rows']),'unique actual capsules');reports=[];controls=0
 for i,(row,disposition)in enumerate(zip(rows,f['dispositions'])):
  need(type(disposition['index'])is int and disposition['index']==i,'ordered full100 disposition')
  if row['status']!='RESOURCE_ROW_ACQUIRED_FOR_COUNT':need(disposition==dict(index=i,status=row['status'])and i not in descs,'resource exclusion/failure retained');continue
  cfg,margins=base(row,n,band,i);raw=row['result']['result']
  if i not in descs:
   proof=read(d/f'SCALAR_EXCLUDED_{i}.json');lo,cap=scalar(raw,proof['scalar'],n,band,i);need(lo>F(raw['rho_hi'])and disposition['status']=='EXCLUDED_BY_STRICT_ACTUAL_INWARD_MOMENT','strict scalar exclusion');continue
  C=d/f'capsule{i}';contract=read(C/'contract.json');proof=read(C/'SCALAR_DERIVATION.json');lo,cap=scalar(raw,proof['scalar'],n,band,i)
  need(proof['signed_quadratic_margins']==margins and proof['n']==n and proof['band']==band and proof['index']==i and proof['original_Lambda_preserved']is True,'whole derived scope')
  l,u=m.folded(cfg['p']);coupled=proof['coupled']
  if 0<F(cfg['d0'])<=l:
   need(coupled['coupled_inputs']=={k:cfg[k]for k in('n','index','p','d0','Lambda','rho_upper')}and coupled['scalar_p']==[str(l),str(u)]and coupled['original_Lambda_preserved']is True,'whole coupled source')
   val=ns['coupled_check'](l,u,F(cfg['d0']),F(cfg['rho_upper']),F(cfg['Lambda']),coupled['coupled_derivation'],n);val=min(F(cfg['Lambda']),m.ceiling(val,10**9));need(F(coupled['coupled_lambda_upper'])==val,'independent actualn coupled output');cap=min(cap,val)
  else:need(coupled is None,'explicit optional coupled gate')
  cfg.update(rho_lower=str(lo),acquired_lambda_upper=str(cap));need(bi.same(contract['rows'][0],cfg),'ENTIRE independently reconstructed contract')
  need(contract['n']==n and contract['band']==band and contract['index']==i and contract['resource_candidate_sha256']==f['parent_candidate_sha256']and contract['resource_replay_sha256']==f['parent_acceptance_sha256']and contract['resource_row_sha256']==sha(pf.PARENT/f'n{n}_{band}/rows/{i:03d}.json')and contract['scalar_derivation_sha256']==sha(C/'SCALAR_DERIVATION.json'),'all native actual parent edges')
  desc=descs[i];need(desc['directory']==str(C.relative_to(ROOT))and desc['contract_sha256']==sha(C/'contract.json')and desc['scalar_derivation_sha256']==sha(C/'SCALAR_DERIVATION.json')and disposition['status']=='PREPARED_CONDITIONAL_COUNT_NOT_EXECUTED','native descriptor')
  for port in read(C/'SOURCE_TRANSFORMS.json')['ports']:
   source=ROOT/port['source'];s=source.read_text();need(sha(source)==port['source_sha256'],'literal template source')
   for a,b,k in port['operations']:need(s.count(a)==k,'entire actual port anchor');s=s.replace(a,b)
   need((C/port['output']).read_text()==s and sha(C/port['output'])==port['output_sha256'],'entire actual protocol/constructor port')
  for name,digest in read(C/'KERNEL_COPY_MANIFEST.json')['files'].items():need(sha(C/name)==digest==sha(pf.TEMPLATE/name),'all24 math copies')
  child="import count_protocol as c;from generalized_scope import validate_resources;cfg,b=c.load();validate_resources(cfg);assert cfg['n']=="+str(n)+";assert cfg['index']=="+str(i)+";assert len(c.rootbox(cfg))==5;print('PASS_DOMAIN_ONLY')"
  z=subprocess.run([sys.executable,'-B','-c',child],cwd=C,capture_output=True,text=True,timeout=10);need(z.returncode==0 and z.stdout.strip()=='PASS_DOMAIN_ONLY'and z.stderr=='','actual retained domain gate '+z.stderr)
  for key,value in [('n',True),('n',20),('Lambda','0'),('rho_lower','0'),('acquired_lambda_upper','0'),('sign_premise',{}),('acquired_mean',['0','0']),('p',['0','1'])]:
   bad=deepcopy(cfg);bad[key]=value;need(not bi.same(bad,contract['rows'][0]),'full typed cfg rejects corruption');controls+=1
  reports.append(dict(index=i,contract_sha256=sha(C/'contract.json'),scalar_derivation_sha256=sha(C/'SCALAR_DERIVATION.json'),original_Lambda=cfg['Lambda'],acquired_lambda_upper=cfg['acquired_lambda_upper'],rho_lower=cfg['rho_lower'],whole_signed_quadratics=len(margins),actual_roots=n+1,domain_validated=True))
 need(len(reports)==len(descs),'every count capsule reviewed')
 graph.update(parentgraph);graph.update(sr['files_sha256'])
 for p in(freeze,P/'run_family.py',Path(__file__),H/'review_scalar_moments.py',H/'review_bn_interfaces.py',source_review):graph[str(p.relative_to(ROOT))]=sha(p)
 out=dict(status='PASS_INDEPENDENT_ACTUAL21_24_COUNT_FAMILY_SOURCE_REVIEW',n=n,band=band,framework_sha256=sha(P/'FROZEN_FRAMEWORK.json'),family_sha256=sha(freeze),files_sha256=graph,all100_rows_checked=True,conditional_count_contracts=reports,typed_contract_controls=controls,resource_or_score_oracle_calls=0,scope='Actual resource receipts and simultaneous scalar/physical interfaces checked independently; source permission for bounded discovery and complete fresh native acceptance. Global predecessor and final induction remain separate.')
 dest=H/f'ACTUAL{n}_{band}_COUNT_FAMILY_SOURCE_REVIEW.json'
 with dest.open('x')as o:json.dump(out,o,indent=2);o.write('\n')
 print(out['status'],n,band,len(reports),len(graph),sha(dest))
if __name__=='__main__':main()
