"""Read-only old-frontier necessary-filter probe; final score oracle is mocked."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import importlib.util,json,sys
H=Path(__file__).resolve().parent;R=H.parents[1]
def sha(p):return sha256(p.read_bytes()).hexdigest()
def enc(x):
    if type(x)is F:return str(x)
    if type(x)is dict:return{k:enc(v) for k,v in x.items()}
    if type(x)in(list,tuple):return[enc(v) for v in x]
    return x
def need(x,m):
    if not x:raise ValueError(m)
def main():
    need(__debug__ and sys.flags.dont_write_bytecode,'ordinary no-bytecode')
    need(len(sys.argv)==2 and sys.argv[1]in('BN40_NEW270',),'fixed finite diagnostic')
    tag=sys.argv[1]
    C=R/'continuation_cutoff20_20261016/bn/frontier_v4/p40_quarter0'
    config=json.loads((C/'contract.json').read_text())['rows'][0]
    failure=json.loads((C/'CONSTRUCTION_RUN.json').read_text())
    need(failure['status']=='BOUNDED_CONSTRUCTION_NOT_COMPLETE','genuine saved finite-budget frontier')
    b=[[F(x) for x in pair] for pair in failure['last_open']['box']];k=failure['last_open']['k']
    inputs={str(p.relative_to(R)):sha(p) for p in list(C.glob('*.py'))+[C/'contract.json',C/'CONSTRUCTION_RUN.json',Path(__file__)]}
    sys.path.insert(0,str(C))
    import rho_signed_moment_tightener as signed
    import joint as old
    captures=[]
    def capture(cfg,**kwargs):
        captures.append(kwargs)
        return dict(status='DIAGNOSTIC_MOCK_FINAL_SCORE',kwargs=kwargs)
    signed.base_cell35=capture
    # Full retained scalar/moment validation and exact contractions execute;
    # only the final expensive count scoring callback is replaced.
    result=signed.cell35(config,pl=b[0][0],pu=b[0][1],lo=b[1][0],hi=b[1][1],al=b[2][0],ah=b[2][1],k=k,ul=b[3][0],uh=b[3][1],a0l=b[4][0],a0h=b[4][1])
    vp=R/'cutoff20_20261016/root/joint_endpoint_v3/joint.py'
    spec=importlib.util.spec_from_file_location('independent_v3',vp);new=importlib.util.module_from_spec(spec);spec.loader.exec_module(new)
    inputs[str(vp.relative_to(R))]=sha(vp)
    before_old=old.cell(config,*b[0],*b[1],*b[2]);before_new=new.cell(config,*b[0],*b[1],*b[2])
    after_old=after_new=None
    if captures:
        need(len(captures)==1,'one mocked final callback')
        x=captures[0];args=[x[key] for key in ('pl','pu','lo','hi','al','ah')]
        after_old=old.cell(config,*args);after_new=new.cell(config,*args)
    for p,h in inputs.items():need(sha(R/p)==h,'unchanged diagnostic sources')
    out=enc(dict(status='NECESSARY_FILTER_ORDER_DIAGNOSTIC_NO_COUNT_CERTIFICATE',tag=tag,k=k,original_box=b,signed_result=result,before_v1=before_old,before_v3=before_new,after_v1=after_old,after_v3=after_new,mocked_final_calls=len(captures),score_oracle_calls=0,files_sha256=inputs))
    dest=H/(tag+'_FILTER_ORDER_DIAGNOSTIC.json')
    with dest.open('x')as f:json.dump(out,f,indent=2);f.write('\n')
    print(json.dumps(dict(tag=tag,signed_status=result['status'],before_v1=str(before_old.get('minimum')),before_v3=str(before_new.get('minimum')),after_v1=None if after_old is None else str(after_old.get('minimum')),after_v3=None if after_new is None else str(after_new.get('minimum')),after_empty=None if after_new is None else after_new['empty'],score_oracle_calls=0)))
if __name__=='__main__':main()
