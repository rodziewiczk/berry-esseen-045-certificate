"""Capture an already reviewed existing-evidence-only band composition."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import sys,json,os,signal,subprocess,time
A=Path(__file__).resolve().parent;ROOT=A.parents[1];H=A/'bridge_family_composition_v4'
def sha(p):return sha256(p.read_bytes()).hexdigest()
def write(p,x):
 with p.open('x')as f:json.dump(x,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
def main():
 assert len(sys.argv)==3 and __debug__ and sys.flags.dont_write_bytecode
 n=int(sys.argv[1]);band=sys.argv[2];assert n in(21,22,23,24)and band in('B0','BN')
 review=ROOT/'continuation_cutoff20_20261016/root/ACTUAL_ACCEPTANCE_CONTINUATION_COMPOSITOR_V4_SOURCE_REVIEW.json';selector=H/'SELECTED_FIFTEEN_CONTINUATION_V1.json';rv=json.loads(review.read_text());assert rv['status']=='PASS_INDEPENDENT_ACTUAL21_24_ACCEPTANCE_CONTINUATION_FAMILY_COMPOSITION_SOURCE_REVIEW'
 assert rv['files_sha256'][str((H/'compose.py').relative_to(ROOT))]==sha(H/'compose.py')
 inputs={str(p.relative_to(ROOT)):sha(p)for p in(H/'compose.py',H/'FROZEN_SOURCES.json',review,selector,Path(__file__))}
 dest=A/'family_composition_captures_v4'/f'n{n}_{band}';dest.mkdir(parents=True,exist_ok=False);out=H/f'ACTUAL{n}_{band}_JOINED.json';assert not out.exists()
 command=[sys.executable,'-B','-u',str(H/'compose.py'),str(n),band,str(review),str(selector)];child=None;interrupted=False;timed_out=False;rc=None;started=datetime.now(timezone.utc).isoformat();t=time.monotonic()
 def stop(signum,frame):raise KeyboardInterrupt(signum)
 old={s:signal.signal(s,stop)for s in(signal.SIGINT,signal.SIGTERM)}
 try:
  with(dest/'stdout.txt').open('x')as stdout,(dest/'stderr.txt').open('x')as stderr:
   try:
    mask=signal.pthread_sigmask(signal.SIG_BLOCK,set(old))
    try:
     child=subprocess.Popen(command,cwd=ROOT,stdout=stdout,stderr=stderr,start_new_session=True,preexec_fn=lambda:signal.pthread_sigmask(signal.SIG_SETMASK,mask))
     write(dest/'STARTED.json',dict(pid=child.pid,pgid=child.pid,command=command,cwd=str(ROOT),started_utc=started,inputs_sha256=inputs,n=n,band=band,numerical_oracle_calls=0))
    finally:signal.pthread_sigmask(signal.SIG_SETMASK,mask)
    child.wait(timeout=300)
   except KeyboardInterrupt:interrupted=True
   except subprocess.TimeoutExpired:timed_out=True
   finally:
    for sig in old:signal.signal(sig,signal.SIG_IGN)
    if child is not None and child.poll()is None:
     os.killpg(child.pid,signal.SIGTERM)
     try:child.wait(timeout=5)
     except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
    if child is not None:rc=child.returncode
 finally:
  for sig,handler in old.items():signal.signal(sig,handler)
 changed=[p for p,h in inputs.items()if sha(ROOT/p)!=h];complete=rc==0 and not interrupted and not timed_out and not changed and out.exists()
 if complete:
  x=json.loads(out.read_text());assert x['status']=='PASS_COMPLETE_CONDITIONAL_ACTUAL21_24_BAND_COMPOSITION'and x['n']==n and x['band']==band and x['numerical_resource_or_leaf_oracle_calls']==0
  assert not(dest/'stderr.txt').read_bytes();assert(dest/'stdout.txt').read_text().strip()==f"{x['status']} {n} {band} {x['total_count_leaves']} {sha(out)}"
 record=dict(status='COMPLETE_EXISTING_EVIDENCE_BAND_COMPOSITION'if complete else'INCOMPLETE_COMPOSITION_PRESERVED',n=n,band=band,command=command,cwd=str(ROOT),started_utc=started,finished_utc=datetime.now(timezone.utc).isoformat(),seconds=time.monotonic()-t,returncode=rc,interrupted=interrupted,timed_out=timed_out,pid=child.pid if child else None,pgid=child.pid if child else None,child_reaped=child is not None and child.poll()is not None,inputs_sha256=inputs,changed_inputs=changed,stdout_sha256=sha(dest/'stdout.txt'),stderr_sha256=sha(dest/'stderr.txt'),result_sha256=sha(out)if out.exists()else None,numerical_oracle_calls=0)
 write(dest/'EXECUTION.json',record);print(record['status'],n,band,record['seconds'],record['result_sha256'])
 if not complete:raise SystemExit(2)
if __name__=='__main__':main()
