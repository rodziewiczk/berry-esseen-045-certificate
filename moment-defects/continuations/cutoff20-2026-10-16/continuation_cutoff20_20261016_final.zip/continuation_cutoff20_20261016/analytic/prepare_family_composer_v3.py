"""Source-only explicit mixed-runtime composition port; unchanged mathematics."""
from pathlib import Path
from hashlib import sha256
import json,difflib
A=Path(__file__).resolve().parent;ROOT=A.parents[1];OLD=A/'bridge_family_composition_v2';H=A/'bridge_family_composition_v3';H.mkdir(exist_ok=False);ports={}
h=lambda p:sha256(p.read_bytes()).hexdigest()
def transform(name,replacements):
 s=(OLD/name).read_text();items=[]
 for a,b in replacements:
  assert s.count(a)==1,(name,a,s.count(a));s=s.replace(a,b);items.append([a,b])
 (H/name).write_text(s);(H/(name+'.diff')).write_text(''.join(difflib.unified_diff((OLD/name).read_text().splitlines(True),s.splitlines(True),fromfile=str(OLD/name),tofile=str(H/name))))
 ports[name]=dict(source=str((OLD/name).relative_to(ROOT)),source_sha256=h(OLD/name),transforms=items,new_sha256=h(H/name))
transform('compose.py',[
("SAFETY=A/'RESUMED_COUNT_LAUNCHER_V3_SOURCE_REVIEW.json'","SAFETY=A/'RESUMED_COUNT_LAUNCHER_V3_SOURCE_REVIEW.json'\nNEW_RUNNER=ROOT/'continuation_cutoff20_20261016/root/resume_count_family_v4.py'\nNEW_SAFETY=A/'RESUMED_COUNT_LAUNCHER_V4_SOURCE_REVIEW.json'\n\ndef family_runtime(n,band):\n need(type(n)is int and n in(21,22,23,24)and band in('B0','BN'),'literal fixed runtime family')\n return(NEW_RUNNER,NEW_SAFETY)if n in(23,24)else(RUNNER,SAFETY)"),
("def captured(graph,n,band,i,action,C,family,review):\n cap=","def captured(graph,n,band,i,action,C,family,review):\n RUNNER,SAFETY=family_runtime(n,band)\n cap="),
("PASS_INDEPENDENT_ACTUAL21_24_REPAIRED_FAMILY_COMPOSITION_SOURCE_REVIEW","PASS_INDEPENDENT_ACTUAL21_24_MIXED_RUNTIME_FAMILY_COMPOSITION_SOURCE_REVIEW"),
("FROZEN_ACTUAL21_24_CONDITIONAL_FAMILY_COMPOSITOR_V2","FROZEN_ACTUAL21_24_CONDITIONAL_FAMILY_COMPOSITOR_V3"),
(" safety=closure(graph,SAFETY);"," RUNNER,SAFETY=family_runtime(n,band)\n safety=closure(graph,SAFETY);")])
transform('repair_edges.py',[
("EXPLICIT_ACTUAL21_24_FULL_PANEL_ALPHA8_SELECTION_V1","EXPLICIT_ACTUAL21_24_FULL_PANEL_ALPHA8_SELECTION_V2"),
("  if (nn,bb)==(n,band):chosen[i]=(S,freeze,f,review)","  epoch=r['runtime_epoch'];core.need(epoch in('original_v1','extended_v2'),'explicit supported runtime epoch');runtime=None\n  if epoch=='original_v1':core.need('runtime_review'not in r,'old epoch has no new runtime edge')\n  else:\n   E=A/'alpha8_runtime_v2';runtime_review=(ROOT/r['runtime_review']).resolve();core.need(runtime_review.is_relative_to(ROOT),'local runtime review')\n   rr=core.closure(graph,runtime_review);rf=E/'FROZEN_RUNTIME.json';rfo=core.closure(graph,rf)\n   core.need(rr['status']=='PASS_SAFE_EXTENDED_ALPHA8_COUNT_LAUNCHER_SOURCE_REVIEW'and rfo['status']=='FROZEN_DEADLINE_ONLY_ALPHA8_RUNTIME_WITH_EXPLICIT_PROVENANCE','reviewed explicit extended runtime')\n   for p in(E/'run_action.py',rf,RETRIES/'run_action.py'):core.need(rr['files_sha256'].get(str(p.relative_to(ROOT)))==core.sha(p),'independent runtime review binds both launchers and epoch')\n   core.need(rfo['original_launcher_sha256']==core.sha(RETRIES/'run_action.py'),'unchanged original proof launcher')\n   runtime=dict(launcher=E/'run_action.py',review=runtime_review,freeze=rf)\n  if (nn,bb)==(n,band):chosen[i]=(S,freeze,f,review,runtime)"),
(" S,freeze,f,review=route;C=S/'capsule';"," S,freeze,f,review,runtime=route;C=S/'capsule';"),
("  core.need(e['work_timeout_seconds']==660", "  runtime_keys=('runtime_review_sha256','runtime_freeze_sha256','launcher_sha256','launcher_path')\n  if runtime is None:core.need(all(key not in e and key not in pr for key in runtime_keys),'original runtime record cannot silently carry extended provenance')\n  else:\n   expected_runtime=dict(runtime_review_sha256=core.sha(runtime['review']),runtime_freeze_sha256=core.sha(runtime['freeze']),launcher_sha256=core.sha(runtime['launcher']),launcher_path=str(runtime['launcher'].relative_to(ROOT)))\n   for key,value in expected_runtime.items():core.need(core.same(e[key],value)and core.same(pr[key],value),'entire explicit extended runtime linkage')\n  core.need(e['work_timeout_seconds']==660"),
("  if action=='accept':expected[str((C/f'COUNT{i}_FOREST.json').relative_to(ROOT))]=core.sha(C/f'COUNT{i}_FOREST.json')", "  if runtime is not None:\n   for p in runtime.values():expected[str(p.relative_to(ROOT))]=core.sha(p)\n  if action=='accept':expected[str((C/f'COUNT{i}_FOREST.json').relative_to(ROOT))]=core.sha(C/f'COUNT{i}_FOREST.json')")])
(H/'SOURCE_PORTS.json').write_text(json.dumps(ports,indent=2)+'\n')
(H/'PROOF.txt').write_text('This new source epoch changes only explicitly selected execution provenance. All original n21/n22 full-family captures must use reviewed launcher v3. All n23/n24 original full-family captures must use independently reviewed deadline-only launcher v4. Their actual source hashes and safety reviews are fixed by family_runtime; no fallback or silently inferred source is permitted. The original per-panel mathematical contracts, scalar/physical interfaces, full n+1 geometry and accepted native arithmetic are unchanged.\n\nEach repaired full-panel route now explicitly selects original_v1 or extended_v2. Both retain the original per-scope mathematical/source review and original immutable capsule. Extended routes additionally bind the independent runtime review, epoch and new launcher, require their four exact provenance fields in both durable and final execution records, and include the three exact new runtime inputs in the complete captured input map. Original routes reject unexpected new runtime fields. Every old source/native/coverage gate remains; a missing/partial/interrupted proof is never promoted. Only complete full panels are admissible.\n\nThe whole100-panel/rho-band conclusion remains conditional on GLOBAL sharp(n-1), retained owncap and unrestricted-witness framework. Neither altered deadlines nor runtime metadata change a mathematical inequality or discharge that predecessor. New source approval does not imply actual complete region. No numerical oracle is executed by composition.\n')
# Explicit current selection: completed21 uses original runtime; unopened22 retries use extended runtime.
d=json.loads((OLD/'SELECTED_ALL_FOURTEEN_V5.json').read_text());d['status']='EXPLICIT_ACTUAL21_24_FULL_PANEL_ALPHA8_SELECTION_V2'
for r in d['routes']:
 r['runtime_epoch']='original_v1'if r['n']==21 else'extended_v2'
 if r['n']==22:r['runtime_review']='continuation_cutoff20_20261016/root/ALPHA8_EXTENDED_RUNTIME_V2_SOURCE_REVIEW.json'
(H/'SELECTED_FOURTEEN_MIXED_V1.json').write_text(json.dumps(d,indent=2)+'\n')
g={}
for p in(OLD/'FROZEN_SOURCES.json',ROOT/'continuation_cutoff20_20261016/root/ACTUAL21_24_REPAIRED_FAMILY_COMPOSITION_SOURCE_REVIEW.json',A/'RESUMED_COUNT_LAUNCHER_V4_SOURCE_REVIEW.json',ROOT/'continuation_cutoff20_20261016/root/ALPHA8_EXTENDED_RUNTIME_V2_SOURCE_REVIEW.json'):
 o=json.loads(p.read_text());g[str(p.relative_to(ROOT))]=h(p)
 for k,z in o.get('files_sha256',{}).items():assert h(ROOT/k)==z;assert k not in g or g[k]==z;g[k]=z
for p in list(H.iterdir())+[Path(__file__)]:g[str(p.relative_to(ROOT))]=h(p)
f=dict(status='FROZEN_ACTUAL21_24_CONDITIONAL_FAMILY_COMPOSITOR_V3',files_sha256=g,source_only=True,numerical_oracle_calls=0,mathematical_bounds_changed=False,complete_band_or_global_conclusion_asserted=False)
(H/'FROZEN_SOURCES.json').write_text(json.dumps(f,indent=2)+'\n');print(h(H/'FROZEN_SOURCES.json'),len(g))
